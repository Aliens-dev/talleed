<?php


namespace App\Http\Controllers\Admin;


class AdminTagsController
{

    public function index()
    {
        return view('admin.tags.index');
    }
}
