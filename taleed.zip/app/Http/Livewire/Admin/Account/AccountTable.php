<?php

namespace App\Http\Livewire\Admin\Account;

use Livewire\Component;

class AccountTable extends Component
{

    public function render()
    {
        return view('admin.livewire.account.account-table');
    }
}
