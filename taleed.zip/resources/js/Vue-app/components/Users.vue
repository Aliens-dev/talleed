<template>

</template>

<script>
    export default {
        data() {
            return {
                users: [],
            }
        },
        mounted() {
           this.fetchData()
        },
        methods: {
            fetchData() {

            }
        }
    }
</script>

<style>

</style>
