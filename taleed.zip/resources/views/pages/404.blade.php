@extends('layouts.app')

@section("title", "الصفحة غير موجودة")

@section("content")
        <div class="modal-content p-5 mt-5">
            <div class="title is-4 is-flex is-justify-content-center">
                الصفحة غير موجودة
            </div>
            <div class="modal-image">
                <div class="blue p-5 is-flex is-justify-content-center is-align-items-center">
                    <img src="/assets/img/logo.png" alt="taleed Logo" />
                </div>
            </div>
        </div>
@endsection
