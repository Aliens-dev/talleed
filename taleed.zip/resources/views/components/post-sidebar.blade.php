<div class="post-sidebar">
    <div class="user-details mb-6">
        <div class="my-card no-box-shadow">
            <p class="subtitle is-6 p-2 is-flex is-justify-content-center has-text-white has-background-black">اضافة مقال</p>
        </div>
    </div>
    <div class="user-options mt-5">
        <!-- Add Something here... -->
    </div>
    <div class="user-edit is-flex is-flex-direction-column is-align-items-center mt-6 mb-4">
        {{ $slot }}
    </div>
</div>
