@extends('admin.layouts.auth')

    @section('content')
        <livewire:admin.dashboard-table />
    @endsection
