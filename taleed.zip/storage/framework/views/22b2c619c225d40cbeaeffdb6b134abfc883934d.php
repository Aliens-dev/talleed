<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'الكلمات المفتاحية'); ?>
<div>
    <h1 class="title is-4 p-3">الكلمات المفتاحية</h1>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.tag.tags-table', [])->html();
} elseif ($_instance->childHasBeenRendered('GMaA6rI')) {
    $componentId = $_instance->getRenderedChildComponentId('GMaA6rI');
    $componentTag = $_instance->getRenderedChildComponentTagName('GMaA6rI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GMaA6rI');
} else {
    $response = \Livewire\Livewire::mount('admin.tag.tags-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('GMaA6rI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/admin/tags/index.blade.php ENDPATH**/ ?>