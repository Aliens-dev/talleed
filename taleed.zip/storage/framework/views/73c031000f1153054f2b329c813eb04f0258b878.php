<nav class="top-navbar">
    <div class="container">
        <div class="switch-button hidden">
            <img src="/assets/img/3bars.svg" width="35" height="35" alt="" />
        </div>
        <div class="nav-items">
            <?php if(auth()->guard()->check()): ?>
                <div class="nav-item main-item">
                    <div class="dropdown">
                        <div class="dropdown-trigger">
                            <button class="button" aria-haspopup="true" aria-controls="dropdown-menu">
                                <span class="my-account">
                                    <div>
                                        <img src="/assets/img/user_account_profile.svg" alt="<?php echo e(auth()->user()->username); ?>" />
                                    </div>
                                    <span class="username">
                                        <?php echo e(auth()->user()->username); ?>

                                    </span>
                                </span>
                                <span class="icon is-medium">
                                    <img
                                        src="/assets/img/add_plus.svg"
                                        alt="user"
                                        width="16" height="16"
                                    />
                                </span>
                            </button>
                        </div>
                        <div class="dropdown-menu" id="dropdown-menu" role="menu">
                            <div class="dropdown-content">
                                <a href="<?php echo e(route('users.profile', ['user' => auth()->id()])); ?>" class="dropdown-item">
                                    حسابي
                                </a>
                                <a href="<?php echo e(route('posts.create')); ?>" class="dropdown-item">
                                    اضافة تدوينة
                                </a>
                                <a href="<?php echo e(route('users.edit', auth()->id())); ?>" class="dropdown-item">
                                    تعديل الحساب
                                </a>
                                <hr class="dropdown-divider">
                                <div class="dropdown-item">
                                    <form method="POST"  action="<?php echo e(route('logout')); ?>" >
                                        <?php echo csrf_field(); ?>
                                        <button class="button">خروج</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
                <div class="nav-item main-item">
                    <a href="<?php echo e(route('register')); ?>" class="nav-link">
                        <img class="animate__animated animate__bounce" src="/assets/img/editpen.svg" width="25" height="25" alt="edit" />
                        <p class="mr-2">
                            كن مدونا
                        </p>
                    </a>
                </div>
            <?php endif; ?>
            <div class="nav-item nav-xl-hidden">
                <a href="<?php echo e(route('index')); ?>" class="nav-link">
                    الرئيسية
                </a>
            </div>
            <?php
                $categories = \App\Models\Category::take(6)->get();
            ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="nav-item">
                    <a href="<?php echo e(route('category.posts.index', $category->slug)); ?>" class="nav-link">
                        <?php echo e($category->name); ?>

                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="nav-item nav-more dropdown">
                <div class="nav-link dropdown-trigger">
                    <div>
                        المزيد
                    </div>
                    <img src="/assets/img/more.svg" width="25" height="25" alt="edit" />
                </div>
                <?php $categories = \App\Models\Category::offset(6)->limit(4)->get() ?>
                <div class="dropdown-menu" id="dropdown-menu" role="menu">
                    <div class="dropdown-content">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('category.posts.index', $category->id)); ?>" class="dropdown-item">
                                <?php echo e($category->name); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/components/topNavbar.blade.php ENDPATH**/ ?>