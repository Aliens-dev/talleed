<div>
    <div class="admin-account mr-2 ml-2">
        <div class="card">
            <div class="card-header">
                <div class="card-header-title">
                    <div class="container">
                            <form action="<?php echo e(route('admin.login.post')); ?>" method="POST" class="login-form">
                                <?php echo csrf_field(); ?>
                                <div class="input-side">
                                    <div class="col">
                                        <div class="input-container">
                                            <label for="fname">الاسم</label>
                                            <input
                                                type="text" name="fname" id="fname" value="<?php echo e($user->fname); ?>"
                                            />
                                            <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="notification is-flex is-danger mt-1 mb-1 p-2">
                                                <span class="delete"></span>
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="input-container">
                                            <label for="lname">اللقب</label>
                                            <input
                                                type="text" name="lname" id="lname" value="<?php echo e($user->lname); ?>"
                                            />
                                            <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="notification is-flex is-danger mt-1 mb-1 p-2">
                                                <span class="delete"></span>
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="input-container">
                                            <label for="email">الايميل</label>
                                            <input
                                                type="text" name="email" id="email" value="<?php echo e($user->email); ?>"
                                            />
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="notification is-flex is-danger mt-1 mb-1 p-2">
                                                    <span class="delete"></span>
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="input-container">
                                            <label for="password">كلمة المرور</label>
                                            <input
                                                type="password" name="password" id="password"
                                            />
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="notification is-flex is-danger mt-1 mb-1 p-2">
                                                <span class="delete"></span>
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <button class="button is-primary">حفظ</button>
                                        <button class="button is-danger">الغاء</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/admin/livewire/account/account-table.blade.php ENDPATH**/ ?>