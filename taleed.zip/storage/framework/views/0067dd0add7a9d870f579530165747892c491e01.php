<?php $__env->startSection('content'); ?>
    <?php $__env->startSection('title', 'المدونين'); ?>
    <div>
        <h1 class="title is-4 p-3">قائمة المدونين</h1>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.user.users-table', [])->html();
} elseif ($_instance->childHasBeenRendered('IVJ3AO7')) {
    $componentId = $_instance->getRenderedChildComponentId('IVJ3AO7');
    $componentTag = $_instance->getRenderedChildComponentTagName('IVJ3AO7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('IVJ3AO7');
} else {
    $response = \Livewire\Livewire::mount('admin.user.users-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('IVJ3AO7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/admin/users/index.blade.php ENDPATH**/ ?>