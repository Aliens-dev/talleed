<?php $__env->startSection('title', $post->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="my-post pt-2 mt-3 mb-5">
        <div class="container">
            <div class="my-card p-2 pt-4 mt-3">
                <?php if (isset($component)) { $__componentOriginal7b86bd86014101847ecc1f63a4df37fbf4b1acdc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SettingsIcon::class, ['post' => $post]); ?>
<?php $component->withName('settings-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal7b86bd86014101847ecc1f63a4df37fbf4b1acdc)): ?>
<?php $component = $__componentOriginal7b86bd86014101847ecc1f63a4df37fbf4b1acdc; ?>
<?php unset($__componentOriginal7b86bd86014101847ecc1f63a4df37fbf4b1acdc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <h1 class="title is-4">
                    <?php echo e($post->title); ?>

                </h1>
                <div class="post-thumbnail">
                    <?php if(\Illuminate\Support\Facades\Storage::exists($post->thumbnail)): ?>
                        <img src="<?php echo e(\Illuminate\Support\Facades\Storage::url($post->thumbnail)); ?>" alt="<?php echo e($post->title); ?>" />
                    <?php else: ?>
                        <img src="/assets/img/thumbnail.jpg" alt="<?php echo e($post->title); ?>" />
                    <?php endif; ?>
                </div>
                <div class="post-author">
                    <div class="author-card">
                        <a href="<?php echo e(route('users.profile', $post->user->id)); ?>" class="author-img">
                            <?php if(\Illuminate\Support\Facades\Storage::exists($post->user->image)): ?>
                                <img src="<?php echo e(\Illuminate\Support\Facades\Storage::url($post->user->user_image)); ?>"
                                     alt="<?php echo e($post->user->fullname); ?>"
                                />
                            <?php else: ?>
                                <img src="/uploads/author.PNG" alt="<?php echo e($post->user->username); ?>"/>
                            <?php endif; ?>
                        </a>
                        <div class="divider-h"></div>
                        <div class="author-info">
                            <a href="<?php echo e(route('users.profile', $post->user->id)); ?>" class="title is-5">
                                <?php echo e($post->user->fullname); ?>

                            </a>
                            <div class="subtitle is-6 is-success">
                                باحث تاريخي
                            </div>
                        </div>
                    </div>
                    <div class="social-share">
                        <a href="">
                            <img src="/assets/img/facebook.svg" alt="facebook">
                        </a>
                        <a href="">
                            <img src="/assets/img/instagram.svg" alt="instagram">
                        </a>
                        <a href="">
                            <img src="/assets/img/twitter.svg" alt="twitter">
                        </a>
                    </div>
                </div>
                <div class="post-body mt-5 mb-3">
                    <?php echo $post->body; ?>

                </div>
            </div>
            <div>
                <?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Sidebar::class, []); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    <?php if(count($post->tags)): ?>
                         <?php $__env->slot('tags'); ?> 
                            <div class="post-tags">
                                <div class="subtitle is-6 is-bold">
                                    الكلمات المفتاحية
                                </div>
                                <div class="btns is-flex">
                                    <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="tag-btn">
                                            <?php echo e($tag->name); ?>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                         <?php $__env->endSlot(); ?>
                    <?php endif; ?>
                 <?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/posts/show.blade.php ENDPATH**/ ?>