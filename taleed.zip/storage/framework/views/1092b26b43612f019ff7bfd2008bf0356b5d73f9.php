

<div class="my-card mb-2 mt-2 p-0 ml-0 mr-0 columns">
    <div class="column <?php echo e($img_col? $img_col : 'is-two-fifths'); ?>">
        <img class="image" src="/uploads/main-post.PNG" alt="" />
    </div>
    <div class="column <?php echo e($img_col? $img_col : 'is-three-fifths'); ?>">
        <header class="card-header is-flex is-flex-direction-column is-justify-content-space-between">
            <h3 class="title is-20 line-height-24 mt-1 mb-2">
                <?php echo e($title); ?>

            </h3>
            <p class="is-size-6 mt-1 mb-3">
                هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها.
            </p>
            <a href="">
                اقرأ المزيد
            </a>
        </header>
    </div>
</div><?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/components/postCard.blade.php ENDPATH**/ ?>