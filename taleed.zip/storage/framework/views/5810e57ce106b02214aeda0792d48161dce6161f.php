<?php $__env->startSection('content'); ?>
    <?php $__env->startSection('title', 'المقالات'); ?>
    <div>
        <h1 class="title is-4 p-3">قائمة المقالات</h1>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.post.posts-table', [])->html();
} elseif ($_instance->childHasBeenRendered('8giwz4L')) {
    $componentId = $_instance->getRenderedChildComponentId('8giwz4L');
    $componentTag = $_instance->getRenderedChildComponentTagName('8giwz4L');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8giwz4L');
} else {
    $response = \Livewire\Livewire::mount('admin.post.posts-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('8giwz4L', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>