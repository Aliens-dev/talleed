<div class="sidebar">
    <?php if(isset($tags)): ?>
        <div class="side-item">
            <?php echo e($tags); ?>

        </div>
    <?php endif; ?>
    <div class="side-item">
        <div class="tabs">
            <ul>
                <li class="is-active">
                    <a data-toggle="popular-section">الاكثر شعبية</a>
                </li>
                <li>
                    <a data-toggle="categories-section">المجالات</a>
                </li>
            </ul>
        </div>
        <div class="tabs-content">
            <div class="items show" id="popular-section">
                <?php $__currentLoopData = $popularPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="post">
                        <div class="post-thumbnail">
                            <?php if(\Illuminate\Support\Facades\Storage::exists($post->thumbnail)): ?>
                                <img src="<?php echo e(\Illuminate\Support\Facades\Storage::url($post->thumbnail)); ?>" alt="<?php echo e($post->title); ?>" />
                            <?php else: ?>
                                <img src="/assets/img/thumbnail.jpg" alt="<?php echo e($post->title); ?>" />
                            <?php endif; ?>
                        </div>
                        <div class="post-info">
                            <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="post-title is-link">
                                <?php echo e($post->title); ?>

                            </a>
                            <div class="post-subinfo">
                                <a href="<?php echo e(route('users.profile', $post->user->id)); ?>">
                                    <?php echo e($post->user->fullname); ?>

                                </a>
                                <div class="post-date">
                                    <?php echo e(\Carbon\Carbon::parse($post->created_at)->locale('ar')->diffForHumans()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="items" id="categories-section">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <a class="is-link" href="<?php echo e(route('category.posts.index', $category->slug)); ?>" >
                            <?php echo e($category->name); ?>

                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/components/sidebar.blade.php ENDPATH**/ ?>