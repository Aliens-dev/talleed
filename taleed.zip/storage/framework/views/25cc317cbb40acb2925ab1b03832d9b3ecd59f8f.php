<?php $__env->startSection('content'); ?>
    <div class="login-page">
        <?php if (isset($component)) { $__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MyDivider::class, []); ?>
<?php $component->withName('my-divider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['hasLine' => true]); ?>
            <a href="<?php echo e(route('index')); ?>">العودة الى الرئيسية</a>
         <?php if (isset($__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d)): ?>
<?php $component = $__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d; ?>
<?php unset($__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div class="container">
            <form action="<?php echo e(route('password.update')); ?>" method="POST" class="login-form">
                <?php echo csrf_field(); ?>
                <div class="input-side">
                    <div class="form-title">
                        تحديث كلمة المرور
                    </div>
                    <input
                        type="hidden" name="token" value="<?php echo e(request()->route('token')); ?>"
                    />
                    <div class="col">
                        <div class="input-container">
                            <label for="email">الايميل</label>
                            <input
                                type="email" name="email" id="email" value="<?php echo e(request()->query('email')); ?>"
                            />
                        </div>
                    </div>
                    <div class="col">
                        <div class="input-container">
                            <label for="password">كلمة المرور</label>
                            <input
                                type="password" name="password" id="password"
                            />
                        </div>
                    </div>
                    <div class="col">
                        <div class="input-container">
                            <label for="password_confirmation">تاكيد كلمة المرور</label>
                            <input
                                type="password" name="password_confirmation" id="password_confirmation"
                            />
                        </div>
                    </div>
                    <div class="col">
                        <div class="input-container control">
                            <button class="button">تاكيد</button>
                        </div>
                    </div>
                    <div class="col">
                        <div class="input-container">
                            <a href="<?php echo e(route('register')); ?>" >
                                انشاء حساب ؟
                            </a>
                        </div>
                    </div>
                </div>
                <div class="form-side">
                    <div class="wrapper"></div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make("layouts.auth", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/auth/reset-password.blade.php ENDPATH**/ ?>