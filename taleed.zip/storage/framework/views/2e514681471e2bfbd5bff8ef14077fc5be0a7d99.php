<?php $__env->startSection('title', "الاشعارات"); ?>

<?php $__env->startSection("content"); ?>
    <?php if(session()->has('profile_activated')): ?>
        <div class="modal is-active timer">
            <div class="modal-background"></div>
            <div class="modal-content">
                <div class="modal-image">
                    <img src="/assets/img/logo.svg" alt="taleed Logo" />
                </div>
                <div class="modal-message">
                    <?php echo e(session()->get('profile_activated')); ?>

                </div>
            </div>
            <button class="modal-close is-large" aria-label="close"></button>
        </div>
    <?php endif; ?>
    <div class="user-profile">
        <div class="container">
            <?php if (isset($component)) { $__componentOriginalc962264fccb141affa90279e6325115965d3bebf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\UserSidebar::class, ['user' => $user]); ?>
<?php $component->withName('user-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <div class="mb-2">
                    <a href="<?php echo e(route('posts.create')); ?>" class="button min-w-140 is-primary is-rounded">اضافة مقالة</a>
                </div>
                <div class="mt-2">
                    <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="button min-w-140 is-link is-rounded">تعديل الحساب</a>
                </div>
             <?php if (isset($__componentOriginalc962264fccb141affa90279e6325115965d3bebf)): ?>
<?php $component = $__componentOriginalc962264fccb141affa90279e6325115965d3bebf; ?>
<?php unset($__componentOriginalc962264fccb141affa90279e6325115965d3bebf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <div class="user-content">
                <div class="my-card p-5 about-author">
                    <div class="card-header is-flex is-flex-direction-column">
                        <h3 class="title is-5 mb-3">نبذة عن المدون</h3>
                        <p class="is-size-6">
                            لوريم ايبسوم هو نموذج افتراضي يوضع في التصاميم لتعرض على العميل ليتصور طريقه وضع النصوص بالتصاميم سواء كانت تصاميم مطبوعه ... بروشور او فلاير على سبيل المثال ... او نماذج مواقع انترنت ...
                        </p>
                    </div>
                </div>
                <div class="is-flex is-justify-content-space-between mt-4 mb-2 p-2">
                    <h1 class="title is-4">
                        الاشعارات
                    </h1>
                    <?php if(count($user->unreadNotifications)): ?>
                        <div class="">
                            <form action="<?php echo e(route('notification.markAsRead')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button class="button is-outlined is-success" >اخفاء الاشعارات</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
                <?php if(count($user->unreadNotifications)): ?>
                    <?php $__currentLoopData = $user->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="message is-primary mb-1">
                            <div class="message-header pt-0 pb-0 pl-1 pr-1">
                                <?php echo e($notification->data['message']); ?>

                                <a href="<?php echo e($notification->data['route']); ?>" class="message-body has-text-white p-2">
                                    <?php echo e(\Carbon\Carbon::parse($notification->data['time'])->locale('ar')->diffForHumans()); ?>

                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?>
                    <div class="card pr-5 pt-2 pb-2 mt-3">
                        لا توجد اشعارات
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/users/notifications.blade.php ENDPATH**/ ?>