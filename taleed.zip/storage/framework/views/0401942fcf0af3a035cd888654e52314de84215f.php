<?php $__env->startSection('title', $category->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="section-page">
        <div class="page-header">
            <div class="category-name">
                <div class="container">
                    <div class="name">
                        <?php echo e($category->name); ?>

                    </div>
                </div>
            </div>
            <div class="container">
                <div class="main-post">
                    <div class="post-img">
                        <?php if(\Illuminate\Support\Facades\Storage::exists($latest[0]->thumbnail)): ?>
                            <img src="<?php echo e(\Illuminate\Support\Facades\Storage::url($latest[0]->thumbnail)); ?>" alt="<?php echo e($latest[0]->title); ?>" />
                        <?php else: ?>
                            <img src="/assets/img/thumbnail.jpg" alt="<?php echo e($latest[0]->title); ?>" />
                        <?php endif; ?>
                    </div>
                    <div class="post-title">
                        <a href="<?php echo e(route('posts.show', $latest[0]->slug)); ?>" >
                            <?php echo e($latest[0]->title); ?>

                        </a>
                    </div>
                    <div class="post-excerpt">
                        <?php echo e($latest[0]->excerpt); ?>

                    </div>
                </div>
                <?php $latest = $latest->splice(1) ?>
                <div class="sub-posts">
                    <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="post">
                            <div class="post-img">
                                <?php if(\Illuminate\Support\Facades\Storage::exists($p->thumbnail)): ?>
                                    <img src="<?php echo e(\Illuminate\Support\Facades\Storage::url($p->thumbnail)); ?>" alt="<?php echo e($p->title); ?>" />
                                <?php else: ?>
                                    <img src="/assets/img/thumbnail.jpg" alt="<?php echo e($p->title); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="post-info">
                                <div class="post-title">
                                    <a href="<?php echo e(route('posts.show', $p->slug)); ?>" >
                                        <?php echo e($p->title); ?>

                                    </a>
                                </div>
                                <div class="post-excerpt">
                                    <?php echo e($p->excerpt); ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MyDivider::class, ['line' => true]); ?>
<?php $component->withName('my-divider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <?php echo e($category->name); ?>

     <?php if (isset($__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d)): ?>
<?php $component = $__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d; ?>
<?php unset($__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <div class="posts-page" id="test">
        <div class="container">
            <div class="posts mt-1">
                <?php if(count($posts)): ?>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(\Illuminate\Support\Facades\Storage::exists($post->thumbnail)): ?>
                            <?php if (isset($component)) { $__componentOriginalb6f7c37376c8c16b0ea5f7170130ebba1dd1f02a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PostCard::class, ['post' => $post,'img' => \Illuminate\Support\Facades\Storage::url($post->thumbnail)]); ?>
<?php $component->withName('post-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb6f7c37376c8c16b0ea5f7170130ebba1dd1f02a)): ?>
<?php $component = $__componentOriginalb6f7c37376c8c16b0ea5f7170130ebba1dd1f02a; ?>
<?php unset($__componentOriginalb6f7c37376c8c16b0ea5f7170130ebba1dd1f02a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        <?php else: ?>
                            <?php if (isset($component)) { $__componentOriginalb6f7c37376c8c16b0ea5f7170130ebba1dd1f02a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PostCard::class, ['post' => $post,'img' => '/assets/img/thumbnail.jpg']); ?>
<?php $component->withName('post-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb6f7c37376c8c16b0ea5f7170130ebba1dd1f02a)): ?>
<?php $component = $__componentOriginalb6f7c37376c8c16b0ea5f7170130ebba1dd1f02a; ?>
<?php unset($__componentOriginalb6f7c37376c8c16b0ea5f7170130ebba1dd1f02a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($posts->links('layouts.my-pagination')); ?>

                <?php else: ?>
                    <div class="alert alert-info">
                        لا توجد اية مقالات
                    </div>
                <?php endif; ?>
            </div>
            <?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Sidebar::class, []); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/categories/index.blade.php ENDPATH**/ ?>