<nav class="top-navbar">
    <div class="container">
        <div class="nav-items">
            <div class="nav-item main-item">
                 <a href="<?php echo e(route('register')); ?>" class="nav-link">
                     كن مدونا
                 </a>
            </div>
            <?php
                $categories = \App\Models\Category::take(8)->get();
            ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="nav-item">
                    <a href="<?php echo e(route('category.index', $category->slug)); ?>" class="nav-link">
                        <?php echo e($category->name); ?>

                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="nav-item">
                <a href="#" class="nav-link">
                    المزيد
                </a>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/layouts/topNavbar.blade.php ENDPATH**/ ?>