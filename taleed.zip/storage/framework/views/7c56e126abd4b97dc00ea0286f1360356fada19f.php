<th wire:click="setOrderField('<?php echo e($name); ?>')" >
    <?php echo e($slot); ?>

    <?php if($visible): ?>
        <?php if($direction === 'ASC'): ?>
            <img src="/assets/img/up-arrow.svg" class="ml-2" width="12" height="12" alt="Up Arrow" />
        <?php else: ?>
            <img src="/assets/img/down-arrow.svg" class="ml-2" width="12" height="12" alt="Up Arrow" />
        <?php endif; ?>
    <?php endif; ?>
</th>
<?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/admin/components/table-header.blade.php ENDPATH**/ ?>