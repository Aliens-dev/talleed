<?php $__env->startSection('content'); ?>
    <?php $__env->startSection('title', 'حسابي'); ?>
    <div>
        <h1 class="title is-4 p-3 mr-4 ml-4">حسابي</h1>
        <div class="admin-account mr-5 ml-5">
            <?php if(session()->has('success')): ?>
                <div class="notification is-success p-1">
                    <?php echo e(session()->get('success')); ?>

                    <button class="delete"></button>
                </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <div class="card-header-title">
                        <div class="container">
                            <form action="<?php echo e(route('admin.account.update')); ?>" method="POST" class="login-form">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <div class="input-side">
                                    <div class="col">
                                        <div class="input-container">
                                            <label for="fname">الاسم</label>
                                            <input
                                                type="text" name="fname" id="fname" value="<?php echo e($user->fname); ?>"
                                            />
                                            <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="notification is-flex is-danger mt-1 mb-1 p-2">
                                                <span class="delete"></span>
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="input-container">
                                            <label for="lname">اللقب</label>
                                            <input
                                                type="text" name="lname" id="lname" value="<?php echo e($user->lname); ?>"
                                            />
                                            <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="notification is-flex is-danger mt-1 mb-1 p-2">
                                                <span class="delete"></span>
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="input-container">
                                            <label for="username">اسم المستخدم</label>
                                            <input
                                                type="text" name="username" id="username" value="<?php echo e($user->username); ?>"
                                            />
                                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="notification is-flex is-danger mt-1 mb-1 p-2">
                                                <span class="delete"></span>
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="input-container">
                                            <label for="email">الايميل</label>
                                            <input
                                                type="text" name="email" id="email" value="<?php echo e($user->email); ?>"
                                            />
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="notification is-flex is-danger mt-1 mb-1 p-2">
                                                <span class="delete"></span>
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="input-container">
                                            <label for="password">كلمة المرور</label>
                                            <input
                                                type="password" name="password" id="password"
                                            />
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="notification is-flex is-danger mt-1 mb-1 p-2">
                                                    <span class="delete"></span>
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <button class="button is-primary">حفظ</button>
                                        <input type="reset" class="button is-danger" value="الغاء">
                                    </div>
                                    <?php if(session()->has('extra_errors')): ?>
                                        <div class="notification is-danger p-1 ml-5 mr-5">
                                            <?php echo e(session()->get('extra_errors')); ?>

                                            <button class="delete"></button>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/admin/account/index.blade.php ENDPATH**/ ?>