<div class="admin-nav">
    <div class="navbar-brand">
        <span class="side-toggle">
            <img src="/assets/img/3bars.svg" alt="menu" />
        </span>
        <span class="nav-toggle"><img src="/assets/img/3bars.svg" alt="menu" /></span>
    </div>
    <div class="navbar-items">
        <div class="navbar-block">
            <div class="navbar-item">
                <a class="navbar-link ripple" href="<?php echo e(route('index')); ?>">الرئيسية</a>
            </div>
        </div>
        <div class="navbar-block">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('notification-component', [])->html();
} elseif ($_instance->childHasBeenRendered('M1uvi8h')) {
    $componentId = $_instance->getRenderedChildComponentId('M1uvi8h');
    $componentTag = $_instance->getRenderedChildComponentTagName('M1uvi8h');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('M1uvi8h');
} else {
    $response = \Livewire\Livewire::mount('notification-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('M1uvi8h', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <div class="navbar-item dropdown">
                <div class="dropdown-trigger">
                    <button class="button" aria-haspopup="true" aria-controls="admin-settings">
                        <span><?php echo e(auth()->user()->fname); ?></span>
                        <span class="icon is-medium">
                            <img src="/uploads/man.svg" alt="user" />
                        </span>
                    </button>
                </div>
                <div class="dropdown-menu" id="admin-settings" role="menu">
                    <div class="dropdown-content">
                        <a href="<?php echo e(route('admin.account.index')); ?>" class="dropdown-item">
                            حسابي
                        </a>
                        <hr class="dropdown-divider">
                        <a href="" class="dropdown-item">
                            <form method="POST"  action="<?php echo e(route('logout')); ?>" >
                                <?php echo csrf_field(); ?>
                                <button class="button">خروج</button>
                            </form>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/admin/components/admin-navbar.blade.php ENDPATH**/ ?>