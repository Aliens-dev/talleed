<?php $__env->startSection('content'); ?>
    <div class="login-page">
        <?php if (isset($component)) { $__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MyDivider::class, []); ?>
<?php $component->withName('my-divider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['hasLine' => true]); ?>
            <a href="<?php echo e(route('index')); ?>">العودة الى الرئيسية</a>
         <?php if (isset($__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d)): ?>
<?php $component = $__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d; ?>
<?php unset($__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div class="container">
            <form action="" method="POST" class="login-form">
                <?php echo csrf_field(); ?>
                <div class="input-side">
                    <div class="form-title">
                        نسيت كلمة المرور ؟
                    </div>
                    <div class="col">
                        <div class="input-container">
                            <label for="email">الايميل</label>
                            <input
                                type="email" name="email" id="email"
                            />
                        </div>
                    </div>
                    <div class="col">
                        <div class="input-container control">
                            <button class="button">ارسال</button>
                        </div>
                    </div>
                    <div class="col">
                        <div class="input-container">
                            <a href="<?php echo e(route('register')); ?>" >
                                انشاء حساب ؟
                            </a>
                        </div>
                    </div>
                </div>
                <div class="form-side">
                    <div class="wrapper"></div>
                    <div></div>
                    <div class="auth-brand">
                        <div class="auth-col-social">
                            <a href="">
                                <img src="/assets/img/twitter.svg" style="width:35px;height: 35px" alt="twitter taleed" />
                            </a>
                            <a href="">
                                <img src="/assets/img/youtube.svg" style="width:35px;height: 35px"  alt="youtube taleed" />
                            </a>
                            <a href="">
                                <img src="/assets/img/instagram.svg" style="width:30px;height: 35px"  alt="instagram taleed" />
                            </a>
                            <a href="">
                                <img src="/assets/img/facebook.svg" style="width:30px;height: 35px"  alt="facebook taleed" />
                            </a>
                            <a href="">
                                <img src="/assets/img/telegram.svg" style="width:35px;height: 35px"  alt="telegram taleed" />
                            </a>
                        </div>
                        <div class="auth-logo">
                            <img src="<?php echo e(asset('./assets/img/logo.svg')); ?>" alt="taleed" />
                        </div>
                        <div class="auth-rights">
                            جميع الحقوق محفوظة @ 2021 موقع تليد
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("layouts.auth", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>