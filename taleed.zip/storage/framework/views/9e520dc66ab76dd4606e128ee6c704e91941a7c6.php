<?php $__env->startSection("title", "تواصل معنا"); ?>

<?php $__env->startSection("content"); ?>
    <?php if(session()->has('success')): ?>
        <div class="modal is-active">
            <div class="modal-background"></div>
            <div class="modal-content">
                <?php if (isset($component)) { $__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MyDivider::class, ['line' => false]); ?>
<?php $component->withName('my-divider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                    <a href="<?php echo e(route('index')); ?>">العودة الى الرئيسية</a>
                 <?php if (isset($__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d)): ?>
<?php $component = $__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d; ?>
<?php unset($__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <div class="modal-image">
                    <img src="/assets/img/logo.svg" alt="taleed Logo" />
                </div>
                <div class="modal-message">
                     <?php echo e(session()->get('success')); ?>

                </div>
            </div>
            <button class="modal-close is-large" aria-label="close"></button>
        </div>
    <?php endif; ?>
    <div class="container pt-2 mt-2">
        <form action="<?php echo e(route('contact')); ?>" method="POST" class="contact-form">
            <?php echo csrf_field(); ?>
            <div class="input-side">
                <div class="form-title">
                    تواصل معنا
                </div>
                <div class="col">
                    <div class="input-container">
                        <label for="subject">الموضوع</label>
                        <input
                            type="text" name="subject" id="subject" value="<?php echo e(old("subject")); ?>"
                        />
                        <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="notification is-flex is-danger mt-1 mb-1 p-2">
                                <span class="delete"></span>
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col">
                    <div class="input-container">
                        <label for="email">الايميل</label>
                        <input
                            type="text" name="email" id="email" value="<?php echo e(old('email')); ?>"
                        />
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="notification is-flex is-danger mt-1 mb-1 p-2">
                            <span class="delete"></span>
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col">
                    <div class="input-container">
                        <label for="type">نوع الرسالة</label>
                        <div class="control">
                            <label class="radio">
                                <input type="radio" value="إستفسار عام" name="type">
                                إستفسار عام
                            </label>
                            <label class="radio">
                                <input type="radio" value="إستفسار حول المحتوى" name="type">
                                إستفسار حول المحتوى
                            </label>
                            <label class="radio">
                                <input type="radio" value="إتفاق إعلانات على موقع تليد" name="type">
                                إتفاق إعلانات على موقع تليد
                            </label>
                        </div>
                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="notification is-flex is-danger mt-1 mb-1 p-2">
                            <span class="delete"></span>
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col">
                    <div class="input-container">
                        <label for="message">الرسالة</label>
                        <textarea class="textarea" name="message" id="message"><?php echo e(old('message')); ?></textarea>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="notification is-flex is-danger mt-1 mb-1 p-2">
                            <span class="delete"></span>
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col">
                    <div class="input-container control">
                        <button class="button">ارسال</button>
                    </div>
                </div>
            </div>
            <div class="contact-side">
                <div class="wrapper"></div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/pages/contact.blade.php ENDPATH**/ ?>