<nav class="main-navbar">
    <div class="container">
        <a href="<?php echo e(route('index')); ?>" class="nav-brand">
            <span class="animate__animated animate__rubberBand logo">
                <img src="<?php echo e(asset('assets/img/logo.svg')); ?>" alt="taleed logo" />
            </span>
            <span>
                تليـــد
            </span>
        </a>
        <div class="nav-items">
            <div class="nav-item">
                <a href="<?php echo e(route('posts.index')); ?>" class="nav-link">
                    مقالات
                </a>
            </div>
            <div class="nav-item">
                <a href="<?php echo e(route('contact')); ?>" class="nav-link">
                    تواصل معنا
                </a>
            </div>
            <div class="nav-item">
                <a href="<?php echo e(route('about')); ?>" class="nav-link">
                    اعرف عنا
                </a>
            </div>
            <div class="nav-item">
                <a href="<?php echo e(route('confidentiality')); ?>" class="nav-link">
                    سياسة الخصوصية
                </a>
            </div>
        </div>
        <div class="nav-search">
            <form class="search-form" action="<?php echo e(route('search')); ?>" method="GET">
                <label>
                    <img src="<?php echo e(asset('assets/img/search.svg')); ?>" alt="search" />
                </label>
                <input type="text" name="search" value="<?php echo e(old('search')); ?>" placeholder="ابحث في الموقع" />
            </form>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/components/mainNavbar.blade.php ENDPATH**/ ?>