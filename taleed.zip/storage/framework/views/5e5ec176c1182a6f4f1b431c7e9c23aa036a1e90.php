<div>
    <?php if(session()->has('success')): ?>
        <div class="pr-3 pl-3 message is-success">
            <div class="message-header">
                <?php echo e(session()->get('success')); ?>

                <span wire:click="closeMessage()" class="delete"></span>
            </div>
        </div>
    <?php endif; ?>
    <div class="table p-3">
        <div class="search">
            <label for="search" class="is-block is-bold mb-3 title is-5">بحث</label>
            <div class="is-flex">
                <input placeholder="ابحث عن مجال" class="input" id="search" name="search" type="text" wire:model.debounce.500ms="search" />
                <div wire:click="toggleAddForm()" class="button is-primary mr-2">
                    <?php if($addFormVisible): ?>
                        الغاء
                    <?php else: ?>
                        اضافة مجال
                    <?php endif; ?>
                </div>
                <?php if(count($selected)): ?>
                    <button wire:click="deleteCategories()" class="button is-danger mr-2">
                        حذف
                    </button>
                <?php endif; ?>
            </div>
        </div>
        <?php if($addFormVisible): ?>
            <div class="card p-5 mt-2">
                <div class="field is-grouped">
                    <label for="name">المجال</label>
                    <div class="control">
                        <input id="name" class="input" wire:model="newCategory.name" />
                    </div>
                    <div class="mr-2 ml-2"></div>
                    <label for="slug">عنوان المجال</label>
                    <div class="control">
                        <input id="slug" class="input" wire:model="newCategory.slug" />
                    </div>
                    <div class="field is-grouped">
                        <div class="control">
                            <button wire:click="addCategory()" class="button is-link">اضافة</button>
                        </div>
                        <div class="control">
                            <button wire:click="toggleAddForm()" class="button is-link is-light mr-2">الغاء</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <table class="mt-2">
            <thead>
            <th>#</th>
            <?php if (isset($component)) { $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TableHeader::class, ['orderBy' => $orderField,'direction' => $orderDirection,'name' => 'id']); ?>
<?php $component->withName('table-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'is-hoverable']); ?>رقم <?php if (isset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36)): ?>
<?php $component = $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36; ?>
<?php unset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TableHeader::class, ['orderBy' => $orderField,'direction' => $orderDirection,'name' => 'name']); ?>
<?php $component->withName('table-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>الاسم <?php if (isset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36)): ?>
<?php $component = $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36; ?>
<?php unset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TableHeader::class, ['orderBy' => $orderField,'direction' => $orderDirection,'name' => 'slug']); ?>
<?php $component->withName('table-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>عنوان المجال <?php if (isset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36)): ?>
<?php $component = $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36; ?>
<?php unset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TableHeader::class, ['orderBy' => $orderField,'direction' => $orderDirection,'name' => 'created_at']); ?>
<?php $component->withName('table-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>تاريخ الانشاء <?php if (isset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36)): ?>
<?php $component = $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36; ?>
<?php unset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <th>تعديل</th>
            </thead>
            <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr wire:key="<?php echo e($category->id); ?>">
                    <td>
                        <input type="checkbox" wire:model="selected" value="<?php echo e($category->id); ?>">
                    </td>
                    <td><?php echo e($category->id); ?></td>
                    <td><?php echo e($category->name); ?></td>
                    <td><?php echo e($category->slug); ?></td>
                    <td><?php echo e($category->created_at->locale('ar')->diffForHumans()); ?></td>
                    <td>
                        <button class="button is-success" wire:click="setEditId('<?php echo e($category->id); ?>')">تعديل</button>
                    </td>
                </tr>
                <?php if($editId == $category->id): ?>
                    <tr>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('categories-edit-form', ['category' => $category])->html();
} elseif ($_instance->childHasBeenRendered(''.e($category->id).'')) {
    $componentId = $_instance->getRenderedChildComponentId(''.e($category->id).'');
    $componentTag = $_instance->getRenderedChildComponentTagName(''.e($category->id).'');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(''.e($category->id).'');
} else {
    $response = \Livewire\Livewire::mount('categories-edit-form', ['category' => $category]);
    $html = $response->html();
    $_instance->logRenderedChild(''.e($category->id).'', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($categories->links('admin.layouts.pagination')); ?>

</div>
<?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/admin/livewire/categories-table.blade.php ENDPATH**/ ?>