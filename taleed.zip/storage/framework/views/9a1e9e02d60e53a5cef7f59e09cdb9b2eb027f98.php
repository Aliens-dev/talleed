<div>
    <?php if(session()->has('success')): ?>
        <div class="pr-3 pl-3 message is-success">
            <div class="message-header">
                <?php echo e(session()->get('success')); ?>

                <span wire:click="closeMessage()" class="delete"></span>
            </div>
        </div>
    <?php endif; ?>
    <div class="table p-3">
        <div class="search">
            <label for="search" class="is-block is-bold mb-3 title is-5">بحث</label>
            <div class="is-flex">
                <input placeholder="ابحث عن مقال" class="input" id="search" name="search" type="text" wire:model.debounce.500ms="search" />
                <?php if(count($selected)): ?>
                    <button wire:click="deletePosts()" class="button is-danger mr-2">
                        حذف
                    </button>
                <?php endif; ?>
            </div>
        </div>
        <table class="mt-2">
            <thead>
                <th>#</th>
                <?php if (isset($component)) { $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TableHeader::class, ['orderBy' => $orderField,'direction' => $orderDirection,'name' => 'id']); ?>
<?php $component->withName('table-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'is-hoverable']); ?>رقم <?php if (isset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36)): ?>
<?php $component = $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36; ?>
<?php unset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TableHeader::class, ['orderBy' => $orderField,'direction' => $orderDirection,'name' => 'title']); ?>
<?php $component->withName('table-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>العنوان <?php if (isset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36)): ?>
<?php $component = $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36; ?>
<?php unset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <th>الكاتب</th>
                <th>المجال</th>
                <th>تاريخ النشر</th>
                <?php if (isset($component)) { $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TableHeader::class, ['orderBy' => $orderField,'direction' => $orderDirection,'name' => 'status']); ?>
<?php $component->withName('table-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>الحالة <?php if (isset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36)): ?>
<?php $component = $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36; ?>
<?php unset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <th>تعديل</th>
            </thead>
            <tbody>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <input type="checkbox" wire:model="selected" value="<?php echo e($post->id); ?>">
                    </td>
                    <td><?php echo e($post->id); ?></td>
                    <td><?php echo e($post->title); ?></td>
                    <td><?php echo e($post->user->fullname); ?></td>
                    <td><?php echo e($post->categories[0]->name); ?></td>
                    <td><?php echo e($post->created_at->locale('ar')->diffForHumans()); ?></td>
                    <td>
                        <div class="select">
                            <select value="<?php echo e($post->status); ?>" wire:change="updateStatus($event.target.value,'<?php echo e($post->id); ?>')">
                                <?php $__currentLoopData = $availableStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($status); ?>"
                                        <?php if($status == $post->status): ?>
                                            selected
                                        <?php endif; ?>
                                    >
                                        <?php echo e($value); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </td>
                    <td>
                        <button class="button is-success" wire:click="setEditId('<?php echo e($post->id); ?>')">تعديل</button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
        <?php echo e($posts->links('admin.layouts.pagination')); ?>

</div>
<?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/admin/livewire/posts-table.blade.php ENDPATH**/ ?>