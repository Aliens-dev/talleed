<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo $__env->yieldContent("title", "لوحة التحكم"); ?></title>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">
        <link rel="stylesheet" href="<?php echo e(asset('css/bulma.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>
    <body>
        <div class="app" id="app">
            <div class="wrapper">
                <?php if (isset($component)) { $__componentOriginal3dbe872005c538aea23c44175c6168a2caf38a9f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminSidebar::class, []); ?>
<?php $component->withName('admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal3dbe872005c538aea23c44175c6168a2caf38a9f)): ?>
<?php $component = $__componentOriginal3dbe872005c538aea23c44175c6168a2caf38a9f; ?>
<?php unset($__componentOriginal3dbe872005c538aea23c44175c6168a2caf38a9f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <div class="content">
                    <?php if (isset($component)) { $__componentOriginal79f5bcd49b4ed6dc3a718549bd3c88461e806300 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminNavbar::class, []); ?>
<?php $component->withName('admin-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal79f5bcd49b4ed6dc3a718549bd3c88461e806300)): ?>
<?php $component = $__componentOriginal79f5bcd49b4ed6dc3a718549bd3c88461e806300; ?>
<?php unset($__componentOriginal79f5bcd49b4ed6dc3a718549bd3c88461e806300); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php echo $__env->yieldContent("content"); ?>
                </div>
            </div>
        </div>
        <script src="<?php echo e(asset('js/admin_scripts.js')); ?>"></script>
        <script src="<?php echo e(asset('js/my_script.js')); ?>"></script>
        <?php echo \Livewire\Livewire::scripts(); ?>

        <?php echo $__env->yieldContent('js'); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/admin/layouts/auth.blade.php ENDPATH**/ ?>