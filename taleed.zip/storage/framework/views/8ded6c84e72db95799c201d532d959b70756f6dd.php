<td colspan="6" class="card p-5 mt-2">
    <div class="field is-grouped">
        <label for="name">المجال</label>
        <div class="control">
            <input id="name" class="input" wire:model.defer="category.name" />
            <?php $__errorArgs = ['category.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="help is-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mr-2 ml-2"></div>
        <label for="slug">عنوان المجال</label>
        <div class="control">
            <input id="slug" class="input" wire:model.defer="category.slug" />
            <?php $__errorArgs = ['category.slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="help is-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="field is-grouped">
            <div class="control">
                <button wire:click="editCategory()" class="button is-link">تعديل</button>
            </div>
            <div class="control">
                <button wire:click="cancelEdit()" class="button is-link is-light mr-2">الغاء</button>
            </div>
        </div>
    </div>
</td>
<?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/admin/livewire/categories/categories-edit-form.blade.php ENDPATH**/ ?>