<div>
    <div class="is-flex is-justify-content-center mr-auto ml-auto mt-2">
        <div class="v-card">
            <div class="v-icon">
                <img src="/assets/img/user.svg" width="50" height="50" alt="Users">
            </div>
            <div class="v-card-body">
                <div>عدد المدونين</div>
                <div class="bold">
                    <?php echo e(\App\Models\User::count()); ?>

                </div>
                <div class="progress">
                    <div></div>
                </div>
            </div>
        </div>
        <div class="v-card">
            <div class="v-icon">
                <img src="/assets/img/post.svg" width="50" height="50" alt="Users">
            </div>
            <div class="v-card-body">
                <div>عدد المقالات</div>
                <div class="bold">
                    <?php echo e(\App\Models\Post::count()); ?>

                </div>
                <div class="progress">
                    <div></div>
                </div>
            </div>
        </div>
        <div class="v-card">
            <div class="v-icon">
                <img src="/assets/img/group.svg" width="50" height="50" alt="Users">
            </div>
            <div class="v-card-body">
                <div>عدد الزوار</div>
                <div class="bold">
                    <?php echo e(\App\Models\Visitor::count()); ?>

                </div>
                <div class="progress">
                    <div></div>
                </div>
            </div>
        </div>
    </div>
    <div class="table p-3">
        <div class="search">
            <label for="search" class="is-block is-bold mb-3 title is-5">بحث</label>
            <div class="is-flex">
                <input placeholder="ابحث" class="input" id="search"
                       name="search" type="text" wire:model.debounce.500ms="search"
                />
                <?php if(count($selected)): ?>
                    <button wire:click="deletePosts()" class="button is-danger mr-2">
                        حذف
                    </button>
                <?php endif; ?>
            </div>
        </div>
        <table class="mt-2">
            <thead>
                <?php if (isset($component)) { $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TableHeader::class, ['orderBy' => $orderField,'direction' => $orderDirection,'name' => 'id']); ?>
<?php $component->withName('table-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'is-hoverable']); ?>رقم <?php if (isset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36)): ?>
<?php $component = $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36; ?>
<?php unset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TableHeader::class, ['orderBy' => $orderField,'direction' => $orderDirection,'name' => 'title']); ?>
<?php $component->withName('table-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>الايبي <?php if (isset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36)): ?>
<?php $component = $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36; ?>
<?php unset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <th>البلد</th>
                <?php if (isset($component)) { $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TableHeader::class, ['orderBy' => $orderField,'direction' => $orderDirection,'name' => 'created_at']); ?>
<?php $component->withName('table-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>تاريخ الزيارة <?php if (isset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36)): ?>
<?php $component = $__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36; ?>
<?php unset($__componentOriginalc30ad8c2a191ad4361a1cb232afac54beb39ce36); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </thead>
            <tbody>
            <?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $data = \Illuminate\Support\Facades\Http::get('http://www.geoplugin.net/json.gp?ip='.$visitor->visitor_ip)->collect();
                ?>
                <tr>
                    <td><?php echo e($visitor->id); ?></td>
                    <td><?php echo e($visitor->visitor_ip); ?></td>
                    <td>
                        <?php if($data['geoplugin_countryName']): ?>
                            <?php echo e($data['geoplugin_countryName']); ?>

                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($visitor->created_at->locale('ar')->diffForHumans()); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($visitors->links('admin.layouts.pagination')); ?>

</div>
<?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/admin/livewire/dashboard-table.blade.php ENDPATH**/ ?>