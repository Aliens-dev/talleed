<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$post)): ?>
    <div class="settings">
        <div class="dropdown">
            <div class="dropdown-trigger">
                <button class="button" aria-haspopup="true" aria-controls="dropdown">
                    <img class="menu-icon" src="/assets/img/menu.svg" alt="more" />
                </button>
            </div>
            <div class="dropdown-menu" id="dropdown" role="menu">
                <div class="dropdown-content">
                    <a href="<?php echo e(route('posts.edit',$post->id)); ?>" class="dropdown-item">
                        تعديل
                    </a>
                    <hr class="dropdown-divider">
                    <a href="#" class="dropdown-item delete-item" data-id="<?php echo e($post->id); ?>" >حذف</a>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startSection('js'); ?>
        <script>
            const deleteItems = document.querySelectorAll('.delete-item')
            deleteItems.forEach(deleteItem => {
                deleteItem.addEventListener('click', function(e) {
                    e.preventDefault()
                    id = e.target.getAttribute('data-id')
                    axios.delete(`/posts/${id}`)
                    .then(()=> {
                        location.reload()
                    })
                });
            })
        </script>
    <?php $__env->stopSection(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/components/settings-icon.blade.php ENDPATH**/ ?>