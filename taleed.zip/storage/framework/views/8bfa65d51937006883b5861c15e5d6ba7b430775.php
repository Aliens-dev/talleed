<div class="has-background-white p-3">
    <?php if($paginator->hasPages()): ?>
        <nav class="pagination is-centered" role="navigation" aria-label="pagination">
            <span>
                
                <?php if($paginator->onFirstPage()): ?>
                    <span class="pagination-previous" disabled>
                        السابق
                    </span>
                <?php else: ?>
                    <a wire:click="previousPage" wire:loading.attr="disabled" rel="prev" class="pagination-previous">
                        السابق
                    </a>
                <?php endif; ?>
            </span>

            <span>
                
                <?php if($paginator->hasMorePages()): ?>
                    <a wire:click="nextPage" wire:loading.attr="disabled" rel="next" class="pagination-next">
                        التالي
                    </a>
                <?php else: ?>
                    <span class="pagination-next" disabled>
                        التالي
                    </span>
                <?php endif; ?>
            </span>

            <ul class="pagination-list mt-0">
                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(is_string($element)): ?>
                        <li>
                            <a class="pagination-ellipsis">
                                <?php echo e($element); ?>

                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if(is_array($element)): ?>
                        <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page=>$url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php if($page == $paginator->currentPage()): ?>
                                <li class="mt-0" wire:key="paginator-page-<?php echo e($page); ?>">
                                    <span class="pagination-link is-current">
                                        <?php echo e($page); ?>

                                    </span>
                                </li>
                            <?php else: ?>
                                <li class="mt-0"  wire:key="paginator-page-<?php echo e($page); ?>">
                                    <a class="pagination-link"
                                       wire:click="gotoPage('<?php echo e($page); ?>')"
                                    >
                                        <?php echo e($page); ?>

                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </nav>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/admin/layouts/pagination.blade.php ENDPATH**/ ?>