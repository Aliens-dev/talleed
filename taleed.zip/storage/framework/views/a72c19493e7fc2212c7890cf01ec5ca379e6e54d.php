    <?php $__env->startSection('content'); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.dashboard-table', [])->html();
} elseif ($_instance->childHasBeenRendered('8t7FFzu')) {
    $componentId = $_instance->getRenderedChildComponentId('8t7FFzu');
    $componentTag = $_instance->getRenderedChildComponentTagName('8t7FFzu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8t7FFzu');
} else {
    $response = \Livewire\Livewire::mount('admin.dashboard-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('8t7FFzu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/admin/index.blade.php ENDPATH**/ ?>