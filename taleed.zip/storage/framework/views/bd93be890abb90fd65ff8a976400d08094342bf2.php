<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'المجالات'); ?>
<div>
    <h1 class="title is-4 p-3">قائمة المجالات</h1>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.category.categories-table', [])->html();
} elseif ($_instance->childHasBeenRendered('BNBMb3X')) {
    $componentId = $_instance->getRenderedChildComponentId('BNBMb3X');
    $componentTag = $_instance->getRenderedChildComponentTagName('BNBMb3X');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BNBMb3X');
} else {
    $response = \Livewire\Livewire::mount('admin.category.categories-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('BNBMb3X', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>