<?php $__env->startSection('title', "الرئيسية"); ?>
<?php $__env->startSection('content'); ?>
    <div class="section-page">
        <div class="page-header">
            <div class="container">
                <div class="main-post">
                    <div class="post-img">
                        <?php if(\Illuminate\Support\Facades\Storage::exists($latest[0]->thumbnail)): ?>
                            <img src="<?php echo e(\Illuminate\Support\Facades\Storage::url($latest[0]->thumbnail)); ?>" alt="<?php echo e($latest[0]->title); ?>" />
                        <?php else: ?>
                            <img src="/assets/img/thumbnail.jpg" alt="<?php echo e($latest[0]->title); ?>" />
                        <?php endif; ?>
                    </div>
                    <div class="post-title">
                        <a href="<?php echo e(route('posts.show', $latest[0]->slug)); ?>" >
                            <?php echo e($latest[0]->title); ?>

                        </a>
                    </div>
                    <div class="post-excerpt">
                        <?php echo e($latest[0]->excerpt); ?>

                    </div>
                </div>
                <?php $latest = $latest->splice(1) ?>
                <div class="sub-posts">
                    <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="post">
                            <div class="post-img">
                                <?php if(\Illuminate\Support\Facades\Storage::exists($post->thumbnail)): ?>
                                    <img src="<?php echo e(\Illuminate\Support\Facades\Storage::url($post->thumbnail)); ?>" alt="<?php echo e($post->title); ?>" />
                                <?php else: ?>
                                    <img src="/assets/img/thumbnail.jpg" alt="<?php echo e($post->title); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="post-info">
                                <div class="post-title">
                                    <a href="<?php echo e(route('posts.show', $post->slug)); ?>" >
                                        <?php echo e($post->title); ?>

                                    </a>
                                </div>
                                <div class="post-excerpt">
                                    <?php echo e($post->excerpt); ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <?php if (isset($component)) { $__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MyDivider::class, ['line' => true]); ?>
<?php $component->withName('my-divider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            المواضيع الاكثر قراءة
         <?php if (isset($__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d)): ?>
<?php $component = $__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d; ?>
<?php unset($__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div class="latest-section">
            <div class="container">
                <div class="posts">
                    <?php $__currentLoopData = $topRead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="post">
                            <?php if (isset($component)) { $__componentOriginal7b86bd86014101847ecc1f63a4df37fbf4b1acdc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SettingsIcon::class, ['post' => $post]); ?>
<?php $component->withName('settings-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal7b86bd86014101847ecc1f63a4df37fbf4b1acdc)): ?>
<?php $component = $__componentOriginal7b86bd86014101847ecc1f63a4df37fbf4b1acdc; ?>
<?php unset($__componentOriginal7b86bd86014101847ecc1f63a4df37fbf4b1acdc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <div class="post-info">
                                <div class="post-title">
                                    <a href="<?php echo e(route('posts.show', $post->slug)); ?>" >
                                        <?php echo e($post->title); ?>

                                    </a>
                                </div>
                                <div class="post-excerpt">
                                    <?php echo e($post->excerpt); ?>

                                </div>
                                <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="more-button">
                                    اقرأ المزيد
                                </a>
                            </div>
                            <div class="post-img is-flex is-flex-direction-column">
                                <?php if(\Illuminate\Support\Facades\Storage::exists($post->thumbnail)): ?>
                                    <img src="<?php echo e(\Illuminate\Support\Facades\Storage::url($post->thumbnail)); ?>" alt="<?php echo e($post->title); ?>" />
                                <?php else: ?>
                                    <img src="/assets/img/thumbnail.jpg" alt="<?php echo e($post->title); ?>" />
                                <?php endif; ?>
                                <div class="post-date">
                                    <?php echo e(date_format($post->created_at,'d/m/Y')); ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="banner"></div>
            </div>
            <?php if (isset($component)) { $__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MyDivider::class, ['line' => true]); ?>
<?php $component->withName('my-divider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                <a href="<?php echo e(route('posts.index')); ?>">
                    مشاهدة كل التدوينات
                </a>
             <?php if (isset($__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d)): ?>
<?php $component = $__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d; ?>
<?php unset($__componentOriginal5e36acc80c8ed854720c205e37681b089404aa4d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/index.blade.php ENDPATH**/ ?>