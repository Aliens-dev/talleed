<div class="post">
    <?php if (isset($component)) { $__componentOriginal7b86bd86014101847ecc1f63a4df37fbf4b1acdc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SettingsIcon::class, ['post' => $post]); ?>
<?php $component->withName('settings-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal7b86bd86014101847ecc1f63a4df37fbf4b1acdc)): ?>
<?php $component = $__componentOriginal7b86bd86014101847ecc1f63a4df37fbf4b1acdc; ?>
<?php unset($__componentOriginal7b86bd86014101847ecc1f63a4df37fbf4b1acdc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <div class="post-info">
        <div class="post-title">
            <a href="<?php echo e(route('posts.show', $post->slug)); ?>" >
                <?php echo e($post->title); ?>

            </a>
        </div>
        <div class="post-excerpt">
            <?php echo e($post->excerpt); ?>

        </div>
        <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="more-button">
            اقرأ المزيد
        </a>
    </div>
    <div class="post-img is-flex is-flex-direction-column">
        <?php if(\Illuminate\Support\Facades\Storage::exists($post->thumbnail)): ?>
            <img src="<?php echo e(\Illuminate\Support\Facades\Storage::url($post->thumbnail)); ?>" alt="<?php echo e($post->title); ?>" />
        <?php else: ?>
            <img src="/assets/img/thumbnail.jpg" alt="<?php echo e($post->title); ?>" />
        <?php endif; ?>
        <div class="post-date">
            <?php echo e(date_format($post->created_at,'d/m/Y')); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/components/post-card.blade.php ENDPATH**/ ?>