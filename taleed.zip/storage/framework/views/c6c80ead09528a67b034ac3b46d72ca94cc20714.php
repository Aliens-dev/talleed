<div class="more-bar">
    <?php if($line): ?>
        <div class="bar"></div>
    <?php endif; ?>
    <div class="bar-text">
        <span>
            <?php echo e($slot); ?>

        </span>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\my_apps\my_projects\taleed\resources\views/components/my-divider.blade.php ENDPATH**/ ?>