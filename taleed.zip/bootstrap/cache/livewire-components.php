<?php return array (
  'admin.account.account-table' => 'App\\Http\\Livewire\\Admin\\Account\\AccountTable',
  'admin.category.categories-edit-form' => 'App\\Http\\Livewire\\Admin\\Category\\CategoriesEditForm',
  'admin.category.categories-table' => 'App\\Http\\Livewire\\Admin\\Category\\CategoriesTable',
  'admin.dashboard-table' => 'App\\Http\\Livewire\\Admin\\DashboardTable',
  'admin.post.posts-table' => 'App\\Http\\Livewire\\Admin\\Post\\PostsTable',
  'admin.tag.tags-edit-form' => 'App\\Http\\Livewire\\Admin\\Tag\\TagsEditForm',
  'admin.tag.tags-table' => 'App\\Http\\Livewire\\Admin\\Tag\\TagsTable',
  'admin.user.users-table' => 'App\\Http\\Livewire\\Admin\\User\\UsersTable',
  'notification-component' => 'App\\Http\\Livewire\\NotificationComponent',
);