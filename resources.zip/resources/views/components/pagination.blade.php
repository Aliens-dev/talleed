<nav class="pagination mt-6 mb-3 ml-0 mr-0" role="navigation" aria-label="pagination">
    <ul class="pagination-list is-flex is-justify-content-center">
        <li>
            <a class="pagination-link is-current" aria-label="Goto page 1" aria-current="page">1</a>
        </li>
        <li>
            <a class="pagination-link" aria-label="Goto page 45">2</a>
        </li>
        <li>
            <span class="pagination-ellipsis">&hellip;</span>
        </li>
        <li>
            <a class="pagination-link" aria-label="Page 46" >8</a>
        </li>
        <li>
            <a class="pagination-link" aria-label="Goto page 47">10</a>
        </li>
    </ul>
  </nav>
